## ENV Variables for CLI
There are a few env variables that need to set for the cli and unit tests. 

Set following ENV variables for using AWS S3
* **AWS_ACCESS_KEY_ID:** S3 access key
* **AWS_SECRET_ACCESS_KEY:** S3 secret key
* **AWS_DEFAULT_REGION:** Region
* **AWS_ACCESS_TOKEN:** Specify only if using IAM credentials
* **AWS_ENDPOINT:** Specify only if using S3 compatable storage. Format http://host:port 

Set the following ENV variable for using Google Cloud Storage
* **GOOGLE_APPLICATION_CREDENTIALS:** Path to json file containing the credentials

Set the following ENV variables for using Azure
* **AZURE_STORAGE_END_POINT:** End point of the form https://<StorageAccount>.blob.core.windows.net
* **AZURE_STORAGE_SAS_TOKEN:** The sas token access the containers in the azure storage account

Set the following ENV varaible for using NFS
* **YBC_NFS_DIR:** NFS directory to use

## Help
To get help for the cli, run:
> build/bin/yb-controller-cli help 

Example on how to create a backup of the database named wh2500:
> build/bin/yb-controller-cli backup --bucket cstestfull --cloud_type google --tserver_ip 10.150.2.56 --ns wh2500 --ns_type ysql --wait

This will output a task id that can be specified as the cloud_dir during restore.

Example on how to restore from a backup to a database named restorewh2500 which had its task id as 90c5e013-313d-4f51-9f63-8cb8ca96c50a:
> build/bin/yb-controller-cli restore --bucket cstestfull --cloud_type google --tserver_ip 10.150.2.56 --ns restorewh2500 --ns_type ysql --wait --cloud_dir 90c5e013-313d-4f51-9f63-8cb8ca96c50a

